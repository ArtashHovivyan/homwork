package com.epam.servlet;

import com.epam.manager.ResultManager;
import com.epam.models.Result;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = "/result")
public class ResultServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cookie cookie = new Cookie("java","test");
        cookie.setMaxAge(60*5);
        resp.addCookie(cookie);
        ResultManager resultManager = new ResultManager();
        String pollId = req.getParameter("id");
        int x = 0;
        String[] values = req.getParameterValues("weights");
        int[] s = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            s[i] = Integer.parseInt(values[i]);
            x = x + s[i];
        }
        Result result = resultManager.getByPollId(pollId);
        String b = result.getExplanation();
        String[] c = b.split(",");

        if (result.getMaxScore() == x) {
            req.setAttribute("massage",c[0]);
            req.setAttribute("massage1",c[1]);
            req.getRequestDispatcher("result.jsp").forward(req,resp);

        }else if (x>= result.getMaxScore()/2){
            req.setAttribute("massage",c[0]);
            req.setAttribute("massage1",c[2]);
            req.getRequestDispatcher("result.jsp").forward(req,resp);

        }else  if (x<result.getMaxScore()/2 && x<result.getMinScore()){
            req.setAttribute("massage",c[0]);
            req.setAttribute("massage1",c[3]);
            req.getRequestDispatcher("result.jsp").forward(req,resp);
        } else if(x == result.getMinScore()){
            req.setAttribute("massage",c[0]);
            req.setAttribute("massage1",c[4]);
            req.getRequestDispatcher("result.jsp").forward(req,resp);
        }
    }
}
