package com.epam.servlet;

import com.epam.manager.PollManager;
import com.epam.manager.QuestionManager;
import com.epam.models.Poll;
import com.epam.models.Question;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = "/passTest")
public class PassTestServlet extends HttpServlet {
    PollManager pollManager = new PollManager();
    QuestionManager questionManager = new QuestionManager();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String massage = "You have already passed the test, try again in 5 minutes";
        Cookie[] cookies = req.getCookies();
        for (Cookie cookie : cookies) {
            if (cookie.getValue().equals("test")) {
                req.setAttribute("massage", massage);
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            }
        }
        String id = req.getParameter("id");
        Poll poll = pollManager.getByID(id);
        List<Question> questionList = questionManager.getByPollId(poll.getId());
        poll.setQuestions(questionList);
        req.setAttribute("poll", poll);
        req.getRequestDispatcher("passTest.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
