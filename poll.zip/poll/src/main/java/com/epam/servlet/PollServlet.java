package com.epam.servlet;

import com.epam.manager.PollManager;
import com.epam.models.Poll;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@WebServlet(urlPatterns = "/addPoll")
public class PollServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("addPoll.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Poll poll = new Poll();
        poll.setName(req.getParameter("name"));
        poll.setDescription(req.getParameter("description"));
        PollManager pollManager = new PollManager();
        int pollId = pollManager.addPoll(poll);
        req.setAttribute("pollId",pollId);
        req.getRequestDispatcher("/addResult.jsp").forward(req, resp);
    }

}
