package com.epam.servlet;

import com.epam.manager.ResultManager;
import com.epam.models.Result;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/addResult")
public class AddResultServlet  extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Result result = new Result();
        ResultManager resultManager = new ResultManager();
        result.setExplanation(req.getParameter("explanation"));
        result.setMinScore(Integer.parseInt(req.getParameter("min-score")));
        result.setMaxScore(Integer.parseInt(req.getParameter("max-score")));
        String pollId = req.getParameter("id");
        resultManager.addResult(result, pollId);
        req.setAttribute("pollID",pollId);
       req.getRequestDispatcher("/addAnswerAndQuestion.jsp").forward(req,resp);
    }
}
