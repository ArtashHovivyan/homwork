package com.epam.servlet;

import com.epam.manager.PollManager;
import com.epam.models.Poll;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@WebServlet(urlPatterns = "/pageTest")
public class PageTest extends HttpServlet {
    PollManager pollManager = new PollManager();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

      List<Poll> pollList =pollManager.findAll();
      req.setAttribute("polls",pollList);
        req.getRequestDispatcher("/pageTest.jsp").forward(req,resp);
    }
}
