package com.epam.servlet;

import com.epam.manager.AnswerManager;
import com.epam.manager.PollManager;
import com.epam.manager.QuestionManager;
import com.epam.models.Answer;
import com.epam.models.Poll;
import com.epam.models.Question;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = "/addAnswer")
public class AnswerServlet extends HttpServlet {
    AnswerManager answerManager = new AnswerManager();
    QuestionManager questionManager = new QuestionManager();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        PollManager pollManager = new PollManager();
        List<Poll> polls = new ArrayList<>(pollManager.findAll());
        req.setAttribute("polls", polls);
        req.getRequestDispatcher("addAnswerAndQuestion.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Answer> answers = new ArrayList<>();
        String poolId = req.getParameter("pollId");
        Question question = new Question();
        question.setText(req.getParameter("question"));
        question.setAnswers(answers);
       int x= questionManager.addQuestions(question,poolId );
        for (int i = 1; i < 4; i++) {
            Answer answer = new Answer();
            answer.setText(req.getParameter("answer" + i));
            answer.setWeight(Integer.parseInt(req.getParameter("weight" + i)));
            answers.add(answer);
            answerManager.addAnswer(answer,x);
        }
        req.setAttribute("pollID", poolId);
        req.getRequestDispatcher("addAnswerAndQuestion.jsp").forward(req, resp);

    }
}
