package com.epam.repository;

import com.epam.models.Answer;

import java.util.List;

public interface AnswerRepository <T, E> {


    void addAnswer(T answer,int id);

    List<Answer> findByQuestionId(int id);
}
