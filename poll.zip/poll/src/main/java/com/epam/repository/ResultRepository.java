package com.epam.repository;

import com.epam.models.Result;

public interface ResultRepository<T, E> {
    void addResult(Result result, String pollId);

    Result getByPollId(String pollId);

}
